import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
			// Finská sauna - dřevěné tóny
				wood: {
					warm: 'hsl(var(--wood-warm))',
					light: 'hsl(var(--wood-light))',
					dark: 'hsl(var(--wood-dark))',
					honey: 'hsl(var(--wood-honey))'
				},
				cream: 'hsl(var(--cream))',
				stone: {
					DEFAULT: 'hsl(var(--stone))',
					light: 'hsl(var(--stone-light))'
				},
				// Jantarová akcentní paleta
				amber: {
					DEFAULT: 'hsl(var(--amber))',
					light: 'hsl(var(--amber-light))',
					dark: 'hsl(var(--amber-dark))'
				},
				ember: {
					glow: 'hsl(var(--ember-glow))'
				},
				// Legacy alias pro kompatibilitu
				luxury: {
					gold: 'hsl(var(--amber))',
					'gold-light': 'hsl(var(--amber-light))',
					'gold-dark': 'hsl(var(--amber-dark))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			backgroundImage: {
				'gradient-hero': 'var(--gradient-hero)',
				'gradient-about': 'var(--gradient-about)',
				'gradient-services': 'var(--gradient-services)',
				'gradient-pricing': 'var(--gradient-pricing)',
				'gradient-contact': 'var(--gradient-contact)'
			},
			boxShadow: {
				'soft': 'var(--shadow-soft)',
				'warm': 'var(--shadow-warm)'
			},
			fontFamily: {
				sans: ['Inter', 'system-ui', 'sans-serif'],
				playfair: ['Playfair Display', 'serif'],
				display: ['Cormorant Garamond', 'Georgia', 'serif'],
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-in': {
					'0%': {
						opacity: '0',
						transform: 'translateY(20px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'fade-in-up': {
					'0%': {
						opacity: '0',
						transform: 'translateY(30px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'slide-in-left': {
					'0%': {
						opacity: '0',
						transform: 'translateX(-30px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateX(0)'
					}
				},
				'slide-in-right': {
					'0%': {
						opacity: '0',
						transform: 'translateX(30px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateX(0)'
					}
				},
				'scale-in': {
					'0%': {
						opacity: '0',
						transform: 'scale(0.95)'
					},
					'100%': {
						opacity: '1',
						transform: 'scale(1)'
					}
				},
				'float': {
					'0%, 100%': {
						transform: 'translateY(0px)'
					},
					'50%': {
						transform: 'translateY(-10px)'
					}
				},
			'pulse-glow': {
					'0%, 100%': {
						opacity: '1',
						boxShadow: '0 0 20px hsl(25 75% 50% / 0.4)'
					},
					'50%': {
						opacity: '0.8',
						boxShadow: '0 0 30px hsl(25 75% 50% / 0.6)'
					}
				},
				'spin-slow': {
					'0%': {
						transform: 'rotate(0deg)'
					},
					'100%': {
						transform: 'rotate(360deg)'
					}
				},
				'steam-rise': {
					'0%': {
						transform: 'translateY(0) scale(0.8)',
						opacity: '1'
					},
					'50%': {
						transform: 'translateY(-50vh) scale(1.1)',
						opacity: '0.8'
					},
					'100%': {
						transform: 'translateY(-100vh) scale(1.3)',
						opacity: '0'
					}
				},
				'shimmer': {
					'0%': {
						backgroundPosition: '-200% 0'
					},
					'100%': {
						backgroundPosition: '200% 0'
					}
				},
			'glow-pulse': {
					'0%, 100%': {
						boxShadow: '0 0 20px hsl(25 75% 50% / 0.3), 0 0 40px hsl(25 75% 50% / 0.1)'
					},
					'50%': {
						boxShadow: '0 0 30px hsl(25 75% 50% / 0.5), 0 0 60px hsl(25 75% 50% / 0.2)'
					}
				},
				'text-shimmer': {
					'0%': {
						backgroundPosition: '0% 50%'
					},
					'50%': {
						backgroundPosition: '100% 50%'
					},
					'100%': {
						backgroundPosition: '0% 50%'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-in': 'fade-in 0.6s ease-out',
				'fade-in-up': 'fade-in-up 0.8s ease-out',
				'slide-in-left': 'slide-in-left 0.6s ease-out',
				'slide-in-right': 'slide-in-right 0.6s ease-out',
				'scale-in': 'scale-in 0.5s ease-out',
				'float': 'float 3s ease-in-out infinite',
				'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
				'spin-slow': 'spin-slow 8s linear infinite',
				'steam-rise': 'steam-rise 15s ease-out infinite',
				'shimmer': 'shimmer 3s linear infinite',
				'glow-pulse': 'glow-pulse 3s ease-in-out infinite',
				'text-shimmer': 'text-shimmer 3s ease-in-out infinite'
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
